'use strict'

module.exports = (...data) => {
  const currentLang = data[0] || 'en-gb'
  console.log(process.cwd())
  const trans = require(process.cwd() + '/build/de-de/_/lang/' + currentLang + '.json')
  return trans[data[1]]
}
